import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Code2 } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import LearningPaths from './components/LearningPaths';
import PythonLesson from './components/lessons/PythonLesson';
import CppLesson from './components/lessons/CppLesson';
import PracticeSection from './components/PracticeSection';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/" element={
            <main>
              <Hero />
              <LearningPaths />
            </main>
          } />
          <Route path="/python/:lessonId" element={<PythonLesson />} />
          <Route path="/cpp/:lessonId" element={<CppLesson />} />
          <Route path="/practice" element={<PracticeSection />} />
        </Routes>
        
        <footer className="bg-gray-900 text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="flex items-center">
                  <Code2 className="h-8 w-8 text-indigo-400" />
                  <span className="ml-2 text-xl font-bold">Coding</span>
                </div>
                <p className="mt-4 text-gray-400">
                  Empowering the next generation of programmers with quality education and practical experience.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
                <ul className="space-y-2 text-gray-400">
                  <li><a href="/python/0" className="hover:text-indigo-400">Python Track</a></li>
                  <li><a href="/cpp/0" className="hover:text-indigo-400">C++ Track</a></li>
                  <li><a href="/practice" className="hover:text-indigo-400">Practice Problems</a></li>
                </ul>
              </div>
              <div>
                <h3 className="text-lg font-semibold mb-4">Help Center</h3>
                <ul className="space-y-2 text-gray-400">
                  <li><a href="mailto:charosxonazamova29@gmail.com" className="hover:text-indigo-400">Contact Support</a></li>
                  <li><a href="#" className="hover:text-indigo-400">Documentation</a></li>
                  <li><a href="#" className="hover:text-indigo-400">Community Forum</a></li>
                </ul>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-gray-800 text-center text-gray-400">
              <p>&copy; {new Date().getFullYear()} Coding. All rights reserved.</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;