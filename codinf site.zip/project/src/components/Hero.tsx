import React from 'react';
import { BrainCircuit } from 'lucide-react';

const Hero = () => {
  const scrollToSection = (id: string) => {
    const element = document.querySelector(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative pt-16 pb-32 flex content-center items-center justify-center min-h-screen">
      <div className="absolute top-0 w-full h-full bg-center bg-cover"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80')"
        }}>
        <span className="w-full h-full absolute opacity-50 bg-black"></span>
      </div>
      <div className="container relative mx-auto">
        <div className="items-center flex flex-wrap">
          <div className="w-full lg:w-6/12 px-4 ml-auto mr-auto text-center">
            <div className="text-white">
              <h1 className="text-5xl font-semibold">
                Begin Your Coding Journey
              </h1>
              <p className="mt-4 text-lg text-gray-300">
                Master Python and C++ with our structured learning paths, interactive exercises, and real-world projects. Perfect for beginners and intermediate learners.
              </p>
              <div className="mt-8 flex justify-center space-x-4">
                <button 
                  onClick={() => scrollToSection('#python')}
                  className="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 transition duration-300"
                >
                  Start Python Track
                </button>
                <button 
                  onClick={() => scrollToSection('#cpp')}
                  className="bg-white text-indigo-600 px-6 py-3 rounded-md hover:bg-gray-100 transition duration-300"
                >
                  Start C++ Track
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;