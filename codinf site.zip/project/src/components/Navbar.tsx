import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Code2, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const navigateTo = (path: string) => {
    navigate(path);
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-white shadow-sm fixed w-full z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center cursor-pointer" onClick={() => navigateTo('/')}>
            <Code2 className="h-8 w-8 text-indigo-600" />
            <span className="ml-2 text-xl font-bold">Coding</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            <button onClick={() => navigateTo('/python/0')} className="text-gray-700 hover:text-indigo-600">
              Python
            </button>
            <button onClick={() => navigateTo('/cpp/0')} className="text-gray-700 hover:text-indigo-600">
              C++
            </button>
            <button onClick={() => navigateTo('/practice')} className="text-gray-700 hover:text-indigo-600">
              Practice
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-indigo-600"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          <button 
            onClick={() => navigateTo('/python/0')}
            className="hidden md:block bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
          >
            Start Learning
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <button
                onClick={() => navigateTo('/python/0')}
                className="block w-full text-left px-3 py-2 rounded-md text-gray-700 hover:text-indigo-600 hover:bg-gray-50"
              >
                Python
              </button>
              <button
                onClick={() => navigateTo('/cpp/0')}
                className="block w-full text-left px-3 py-2 rounded-md text-gray-700 hover:text-indigo-600 hover:bg-gray-50"
              >
                C++
              </button>
              <button
                onClick={() => navigateTo('/practice')}
                className="block w-full text-left px-3 py-2 rounded-md text-gray-700 hover:text-indigo-600 hover:bg-gray-50"
              >
                Practice
              </button>
              <button
                onClick={() => navigateTo('/python/0')}
                className="block w-full px-3 py-2 rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Start Learning
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;