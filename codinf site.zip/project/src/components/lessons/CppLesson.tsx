import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import InteractiveCpp from '../InteractiveCpp';

const lessons = [
  {
    title: "Introduction to C++",
    theory: `
# Introduction to C++ Programming

C++ is a powerful, general-purpose programming language that extends C with object-oriented features.

## Basic Structure
- Main function
- Include directives
- Namespaces
- Input/Output

## Variables and Data Types
- int, float, double
- char, string
- bool
- Arrays

## Examples:
\`\`\`cpp
#include <iostream>
using namespace std;

int main() {
    // Variables
    int age = 25;
    float height = 1.75;
    string name = "John";
    
    // Output
    cout << "Name: " << name << endl;
    cout << "Age: " << age << endl;
    
    return 0;
}
\`\`\`
    `,
    task: {
      description: "Create a function that calculates the sum of two numbers",
      initialCode: `#include <iostream>
using namespace std;

int add(int a, int b) {
    // Write your code here
    return 0;
}

int main() {
    int result = add(5, 3);
    cout << "Sum: " << result << endl;
    return 0;
}`,
      solution: `#include <iostream>
using namespace std;

int add(int a, int b) {
    return a + b;
}

int main() {
    int result = add(5, 3);
    cout << "Sum: " << result << endl;  // Should print 8
    return 0;
}`
    }
  },
  {
    title: "Functions and Control Flow",
    theory: `
# Functions and Control Flow in C++

## Functions
- Function declaration and definition
- Parameters and return types
- Pass by value vs. reference
- Function overloading

## Control Structures
- if/else statements
- switch statements
- for loops
- while loops
- do-while loops

## Examples:
\`\`\`cpp
#include <iostream>
using namespace std;

// Function example
int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

int main() {
    // Control flow example
    for (int i = 0; i < 5; i++) {
        cout << factorial(i) << endl;
    }
    return 0;
}
\`\`\`
    `,
    task: {
      description: "Create a function that checks if a number is even or odd",
      initialCode: `#include <iostream>
using namespace std;

bool isEven(int number) {
    // Write your code here
    return false;
}

int main() {
    int num = 4;
    if (isEven(num)) {
        cout << num << " is even" << endl;
    } else {
        cout << num << " is odd" << endl;
    }
    return 0;
}`,
      solution: `#include <iostream>
using namespace std;

bool isEven(int number) {
    return number % 2 == 0;
}

int main() {
    int num = 4;
    if (isEven(num)) {
        cout << num << " is even" << endl;
    } else {
        cout << num << " is odd" << endl;
    }
    return 0;
}`
    }
  },
  {
    title: "Object-Oriented Programming",
    theory: `
# Object-Oriented Programming in C++

## Classes and Objects
- Class definition
- Access specifiers
- Constructors and destructors
- Member functions

## Inheritance
- Base and derived classes
- Virtual functions
- Multiple inheritance

## Examples:
\`\`\`cpp
#include <iostream>
using namespace std;

class Shape {
protected:
    int width, height;
public:
    Shape(int w = 0, int h = 0) {
        width = w;
        height = h;
    }
    virtual int area() = 0;
};

class Rectangle: public Shape {
public:
    Rectangle(int w, int h): Shape(w, h) {}
    int area() {
        return width * height;
    }
};
\`\`\`
    `,
    task: {
      description: "Create a simple class representing a Circle with a method to calculate its area",
      initialCode: `#include <iostream>
using namespace std;

class Circle {
    // Write your code here
};

int main() {
    Circle c(5);
    cout << "Area: " << c.area() << endl;
    return 0;
}`,
      solution: `#include <iostream>
using namespace std;

class Circle {
private:
    double radius;
public:
    Circle(double r) : radius(r) {}
    
    double area() {
        return 3.14159 * radius * radius;
    }
};

int main() {
    Circle c(5);
    cout << "Area: " << c.area() << endl;
    return 0;
}`
    }
  }
];

const CppLesson = () => {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const currentLesson = parseInt(lessonId || '0');
  const lesson = lessons[currentLesson];

  const goToLesson = (index: number) => {
    navigate(`/cpp/${index}`);
  };

  return (
    <div className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <button
          onClick={() => goToLesson(currentLesson - 1)}
          disabled={currentLesson === 0}
          className={`flex items-center ${currentLesson === 0 ? 'text-gray-400' : 'text-indigo-600 hover:text-indigo-700'}`}
        >
          <ChevronLeft className="w-5 h-5 mr-1" />
          Previous Lesson
        </button>
        <span className="text-gray-600">
          Lesson {currentLesson + 1} of {lessons.length}
        </span>
        <button
          onClick={() => goToLesson(currentLesson + 1)}
          disabled={currentLesson === lessons.length - 1}
          className={`flex items-center ${currentLesson === lessons.length - 1 ? 'text-gray-400' : 'text-indigo-600 hover:text-indigo-700'}`}
        >
          Next Lesson
          <ChevronRight className="w-5 h-5 ml-1" />
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold mb-6">{lesson.title}</h1>
        
        <div className="prose max-w-none mb-8">
          <div className="bg-gray-50 rounded-lg p-6">
            <pre className="whitespace-pre-wrap text-sm">
              {lesson.theory}
            </pre>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-semibold mb-6">Practice Exercise</h2>
          <InteractiveCpp currentLesson={currentLesson} lesson={lesson} />
        </div>
      </div>
    </div>
  );
};

export default CppLesson;