import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import InteractivePython from '../InteractivePython';

const lessons = [
  {
    title: "Introduction to Python",
    theory: `
# Introduction to Python Programming

Python is a high-level, interpreted programming language known for its simplicity and readability. Let's start with the basics:

## Variables and Data Types
- Numbers (int, float)
- Strings (str)
- Booleans (bool)
- Lists, tuples, and dictionaries

## Basic Syntax
- Indentation is important
- Comments use #
- Print statements
- Basic operators

## Examples:
\`\`\`python
# Variables
name = "John"
age = 25
height = 1.75
is_student = True

# Print
print(f"Name: {name}, Age: {age}")
\`\`\`
    `,
    task: {
      description: "Create a simple calculator that adds two numbers",
      initialCode: `def add_numbers(a, b):
    # Write your code here
    pass

# Test your function
result = add_numbers(5, 3)
print(result)`,
      solution: `def add_numbers(a, b):
    return a + b

# Test your function
result = add_numbers(5, 3)
print(result)  # Should print 8`
    }
  },
  {
    title: "Functions and Control Flow",
    theory: `
# Functions and Control Flow in Python

## Functions
Functions are reusable blocks of code that perform specific tasks.

### Function Definition
\`\`\`python
def greet(name):
    return f"Hello, {name}!"
\`\`\`

## Control Flow
- if/elif/else statements
- for loops
- while loops
- break and continue

### Examples:
\`\`\`python
# If statement
age = 18
if age >= 18:
    print("Adult")
else:
    print("Minor")

# For loop
for i in range(5):
    print(i)
\`\`\`
    `,
    task: {
      description: "Create a function that checks if a number is prime",
      initialCode: `def is_prime(number):
    # Write your code here
    pass

# Test your function
result = is_prime(17)
print(result)`,
      solution: `def is_prime(number):
    if number < 2:
        return False
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            return False
    return True

# Test your function
result = is_prime(17)
print(result)  # Should print True`
    }
  },
  {
    title: "Data Structures",
    theory: `
# Python Data Structures

## Lists
- Ordered, mutable sequences
- Created using square brackets []
- Common operations: append, extend, insert, remove

## Dictionaries
- Key-value pairs
- Created using curly braces {}
- Unordered (in Python < 3.7)

## Examples:
\`\`\`python
# List operations
fruits = ['apple', 'banana', 'orange']
fruits.append('grape')
print(fruits)

# Dictionary operations
person = {
    'name': 'Alice',
    'age': 30,
    'city': 'New York'
}
print(person['name'])
\`\`\`
    `,
    task: {
      description: "Create a function that finds the most frequent element in a list",
      initialCode: `def most_frequent(numbers):
    # Write your code here
    pass

# Test your function
numbers = [1, 2, 3, 2, 4, 2, 5]
result = most_frequent(numbers)
print(result)`,
      solution: `def most_frequent(numbers):
    return max(set(numbers), key=numbers.count)

# Test your function
numbers = [1, 2, 3, 2, 4, 2, 5]
print(result)  # Should print 2`
    }
  }
];

const PythonLesson = () => {
  const { lessonId } = useParams();
  const navigate = useNavigate();
  const currentLesson = parseInt(lessonId || '0');
  const lesson = lessons[currentLesson];

  const goToLesson = (index: number) => {
    navigate(`/python/${index}`);
  };

  return (
    <div className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <button
          onClick={() => goToLesson(currentLesson - 1)}
          disabled={currentLesson === 0}
          className={`flex items-center ${currentLesson === 0 ? 'text-gray-400' : 'text-indigo-600 hover:text-indigo-700'}`}
        >
          <ChevronLeft className="w-5 h-5 mr-1" />
          Previous Lesson
        </button>
        <span className="text-gray-600">
          Lesson {currentLesson + 1} of {lessons.length}
        </span>
        <button
          onClick={() => goToLesson(currentLesson + 1)}
          disabled={currentLesson === lessons.length - 1}
          className={`flex items-center ${currentLesson === lessons.length - 1 ? 'text-gray-400' : 'text-indigo-600 hover:text-indigo-700'}`}
        >
          Next Lesson
          <ChevronRight className="w-5 h-5 ml-1" />
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-8">
        <h1 className="text-3xl font-bold mb-6">{lesson.title}</h1>
        
        <div className="prose max-w-none mb-8">
          <div className="bg-gray-50 rounded-lg p-6">
            <pre className="whitespace-pre-wrap text-sm">
              {lesson.theory}
            </pre>
          </div>
        </div>

        <div className="mt-12">
          <h2 className="text-2xl font-semibold mb-6">Practice Exercise</h2>
          <InteractivePython currentLesson={currentLesson} lesson={lesson} />
        </div>
      </div>
    </div>
  );
};

export default PythonLesson;