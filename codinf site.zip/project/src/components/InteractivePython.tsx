import React, { useState, useEffect } from 'react';
import Editor from "@monaco-editor/react";
import { Play, CheckCircle2, XCircle, ChevronRight, ChevronLeft } from 'lucide-react';

interface Lesson {
  title: string;
  task: {
    description: string;
    initialCode: string;
    solution: string;
  };
}

interface Props {
  currentLesson: number;
  lesson: Lesson;
}

const InteractivePython: React.FC<Props> = ({ currentLesson, lesson }) => {
  const [code, setCode] = useState(lesson.task.initialCode);
  const [output, setOutput] = useState('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showSolution, setShowSolution] = useState(false);

  useEffect(() => {
    setCode(lesson.task.initialCode);
    setOutput('');
    setIsCorrect(null);
    setShowSolution(false);
  }, [currentLesson, lesson]);

  const checkSolution = () => {
    // In a real application, this would connect to a backend
    // For now, we'll do simple string matching
    const userCode = code.replace(/\s+/g, '');
    const solutionCode = lesson.task.solution.replace(/\s+/g, '');
    const isMatch = userCode.includes(solutionCode.substring(solutionCode.indexOf('return')));
    
    setIsCorrect(isMatch);
    setOutput(isMatch 
      ? "Congratulations! Your solution is correct!" 
      : "Try again! Your solution doesn't match the expected output.");
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h3 className="text-xl font-semibold mb-4">{lesson.title}</h3>
      <div className="mb-4">
        <h4 className="font-medium text-gray-700 mb-2">Task:</h4>
        <p className="text-gray-600">
          {lesson.task.description}
        </p>
      </div>
      <div className="mb-4 h-[300px] border rounded-lg overflow-hidden">
        <Editor
          height="100%"
          defaultLanguage="python"
          theme="vs-dark"
          value={code}
          onChange={(value) => setCode(value || '')}
          options={{
            minimap: { enabled: false },
            fontSize: 14,
          }}
        />
      </div>
      <div className="flex justify-between items-center">
        <div className="flex space-x-4">
          <button
            onClick={checkSolution}
            className="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition duration-300"
          >
            <Play className="w-4 h-4 mr-2" />
            Run Code
          </button>
          <button
            onClick={() => setShowSolution(!showSolution)}
            className="text-indigo-600 hover:text-indigo-700 transition duration-300"
          >
            {showSolution ? 'Hide Solution' : 'Show Solution'}
          </button>
        </div>
        {isCorrect !== null && (
          <div className="flex items-center">
            {isCorrect ? (
              <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            ) : (
              <XCircle className="w-5 h-5 text-red-500 mr-2" />
            )}
            <span className={isCorrect ? "text-green-500" : "text-red-500"}>
              {output}
            </span>
          </div>
        )}
      </div>

      {showSolution && (
        <div className="mt-8">
          <h3 className="text-lg font-semibold mb-2">Solution</h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <pre className="text-sm text-gray-700">
              {lesson.task.solution}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default InteractivePython;