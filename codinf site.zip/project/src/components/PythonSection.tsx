import React, { useState } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import InteractivePython from './InteractivePython';

const PythonSection = () => {
  const [currentLesson, setCurrentLesson] = useState(0);

  const pythonExample = `# Basic Python Example
def calculate_factorial(n):
    if n == 0 or n == 1:
        return 1
    return n * calculate_factorial(n - 1)

# Example usage
number = 5
result = calculate_factorial(number)
print(f"Factorial of {number} is {result}")`;

  const lessons = [
    {
      title: "Introduction to Python",
      topics: ["Basic Syntax", "Variables", "Data Types", "Control Flow"],
      task: {
        description: "Create a simple calculator that adds two numbers",
        initialCode: `def add_numbers(a, b):
    # Write your code here
    pass

# Test your function
result = add_numbers(5, 3)
print(result)`,
        solution: `def add_numbers(a, b):
    return a + b

# Test your function
result = add_numbers(5, 3)
print(result)  # Should print 8`
      }
    },
    {
      title: "Functions and Modules",
      topics: ["Function Definition", "Parameters", "Return Values", "Built-in Modules"],
      task: {
        description: "Create a function that checks if a number is prime",
        initialCode: `def is_prime(number):
    # Write your code here
    pass

# Test your function
result = is_prime(17)
print(result)`,
        solution: `def is_prime(number):
    if number < 2:
        return False
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            return False
    return True

# Test your function
result = is_prime(17)
print(result)  # Should print True`
      }
    },
    {
      title: "Data Structures",
      topics: ["Lists", "Tuples", "Dictionaries", "Sets"],
      task: {
        description: "Create a function that finds the most frequent element in a list",
        initialCode: `def most_frequent(numbers):
    # Write your code here
    pass

# Test your function
numbers = [1, 2, 3, 2, 4, 2, 5]
result = most_frequent(numbers)
print(result)`,
        solution: `def most_frequent(numbers):
    return max(set(numbers), key=numbers.count)

# Test your function
numbers = [1, 2, 3, 2, 4, 2, 5]
print(result)  # Should print 2`
      }
    }
  ];

  const startLesson = (index: number) => {
    setCurrentLesson(index);
    const practiceSection = document.querySelector('#practice');
    if (practiceSection) {
      practiceSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="python" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Python Track</h2>
          <p className="mt-4 text-xl text-gray-600">
            Start your journey with Python - Perfect for beginners
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div>
            <h3 className="text-2xl font-semibold mb-6">Why Python?</h3>
            <ul className="space-y-4 text-gray-600">
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">1</span>
                <span>Easy to learn and read - Perfect for beginners</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">2</span>
                <span>Vast ecosystem of libraries and frameworks</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">3</span>
                <span>Used in web development, data science, AI, and more</span>
              </li>
            </ul>
          </div>
          <div className="bg-gray-900 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-white mb-4">Example Code</h3>
            <SyntaxHighlighter 
              language="python"
              style={atomDark}
              className="rounded-md"
            >
              {pythonExample}
            </SyntaxHighlighter>
          </div>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-semibold mb-8 text-center">Course Curriculum</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {lessons.map((lesson, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                <h4 className="text-xl font-semibold mb-4">{lesson.title}</h4>
                <ul className="space-y-2">
                  {lesson.topics.map((topic, topicIndex) => (
                    <li key={topicIndex} className="flex items-center text-gray-600">
                      <span className="h-2 w-2 bg-indigo-600 rounded-full mr-2"></span>
                      {topic}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => startLesson(index)}
                  className="mt-6 w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition duration-300"
                >
                  Start Lesson
                </button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-semibold mb-8 text-center">Interactive Practice</h3>
          <InteractivePython currentLesson={currentLesson} lesson={lessons[currentLesson]} />
        </div>
      </div>
    </section>
  );
};

export default PythonSection;