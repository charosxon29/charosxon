import React, { useState } from 'react';
import Editor from "@monaco-editor/react";
import { Play, CheckCircle2, XCircle, ChevronRight, ChevronLeft } from 'lucide-react';

const lessons = [
  {
    title: "Array Manipulation",
    description: "Learn how to perform basic operations on arrays",
    theory: `Arrays are fundamental data structures that store elements in contiguous memory locations. 
    Common operations include:
    - Insertion
    - Deletion
    - Searching
    - Traversal
    - Sorting`,
    task: "Create a function that reverses an array without using built-in methods.",
    initialCode: `def reverse_array(arr):
    # Write your code here
    # Return the reversed array
    pass

# Test your function
test_array = [1, 2, 3, 4, 5]
result = reverse_array(test_array)
print(result)`,
    solution: `def reverse_array(arr):
    left = 0
    right = len(arr) - 1
    while left < right:
        arr[left], arr[right] = arr[right], arr[left]
        left += 1
        right -= 1
    return arr`,
    testCases: [
      { input: [1, 2, 3, 4, 5], expected: [5, 4, 3, 2, 1] },
      { input: [10, 20], expected: [20, 10] }
    ]
  },
  {
    title: "String Operations",
    description: "Master string manipulation techniques",
    theory: `Strings are sequences of characters. Common operations include:
    - Concatenation
    - Substring extraction
    - Searching
    - Pattern matching
    - Case manipulation`,
    task: "Create a function that checks if a string is a palindrome (reads the same forwards and backwards).",
    initialCode: `def is_palindrome(text):
    # Write your code here
    # Return True if text is palindrome, False otherwise
    pass

# Test your function
test_string = "radar"
result = is_palindrome(test_string)
print(result)`,
    solution: `def is_palindrome(text):
    text = text.lower()
    left = 0
    right = len(text) - 1
    while left < right:
        if text[left] != text[right]:
            return False
        left += 1
        right -= 1
    return True`,
    testCases: [
      { input: "radar", expected: true },
      { input: "hello", expected: false }
    ]
  }
];

const AlgorithmLesson = () => {
  const [currentLesson, setCurrentLesson] = useState(0);
  const [code, setCode] = useState(lessons[currentLesson].initialCode);
  const [output, setOutput] = useState('');
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showSolution, setShowSolution] = useState(false);

  const checkSolution = () => {
    try {
      // In a real application, this would be handled by a backend
      // Here we're doing simple string comparison for demonstration
      const lesson = lessons[currentLesson];
      const userCode = code.replace(/\s+/g, '');
      const solutionCode = lesson.solution.replace(/\s+/g, '');
      const isMatch = userCode.includes(solutionCode.substring(solutionCode.indexOf('return')));
      
      setIsCorrect(isMatch);
      setOutput(isMatch 
        ? "Congratulations! Your solution is correct!" 
        : "Try again! Your solution doesn't match the expected output.");
    } catch (error) {
      setIsCorrect(false);
      setOutput("Error in your code. Please check and try again.");
    }
  };

  const nextLesson = () => {
    if (currentLesson < lessons.length - 1) {
      setCurrentLesson(prev => prev + 1);
      setCode(lessons[currentLesson + 1].initialCode);
      setOutput('');
      setIsCorrect(null);
      setShowSolution(false);
    }
  };

  const prevLesson = () => {
    if (currentLesson > 0) {
      setCurrentLesson(prev => prev - 1);
      setCode(lessons[currentLesson - 1].initialCode);
      setOutput('');
      setIsCorrect(null);
      setShowSolution(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {lessons[currentLesson].title}
            </h2>
            <div className="flex items-center space-x-4">
              <button
                onClick={prevLesson}
                disabled={currentLesson === 0}
                className={`p-2 rounded-full ${currentLesson === 0 ? 'text-gray-400' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <span className="text-gray-600">
                Lesson {currentLesson + 1} of {lessons.length}
              </span>
              <button
                onClick={nextLesson}
                disabled={currentLesson === lessons.length - 1}
                className={`p-2 rounded-full ${currentLesson === lessons.length - 1 ? 'text-gray-400' : 'text-gray-700 hover:bg-gray-100'}`}
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-2">Theory</h3>
            <div className="bg-gray-50 rounded-lg p-4 text-gray-700">
              {lessons[currentLesson].theory.split('\n').map((line, index) => (
                <p key={index} className="mb-2">{line}</p>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Task</h3>
            <p className="text-gray-700">{lessons[currentLesson].task}</p>
          </div>

          <div className="mb-6">
            <div className="h-[400px] border rounded-lg overflow-hidden">
              <Editor
                height="100%"
                defaultLanguage="python"
                theme="vs-dark"
                value={code}
                onChange={(value) => setCode(value || '')}
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                }}
              />
            </div>
          </div>

          <div className="flex justify-between items-center">
            <div className="flex space-x-4">
              <button
                onClick={checkSolution}
                className="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
              >
                <Play className="w-4 h-4 mr-2" />
                Run Code
              </button>
              <button
                onClick={() => setShowSolution(!showSolution)}
                className="text-indigo-600 hover:text-indigo-700"
              >
                {showSolution ? 'Hide Solution' : 'Show Solution'}
              </button>
            </div>
            {isCorrect !== null && (
              <div className="flex items-center">
                {isCorrect ? (
                  <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-500 mr-2" />
                )}
                <span className={isCorrect ? "text-green-500" : "text-red-500"}>
                  {output}
                </span>
              </div>
            )}
          </div>

          {showSolution && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-2">Solution</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                <pre className="text-sm text-gray-700">
                  {lessons[currentLesson].solution}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AlgorithmLesson;