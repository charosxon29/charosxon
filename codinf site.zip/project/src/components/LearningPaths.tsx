import React from 'react';
import { BookOpen, Terminal, FileCode2, BrainCircuit } from 'lucide-react';

const LearningPaths = () => {
  const paths = [
    {
      icon: <BookOpen className="h-12 w-12 text-indigo-600" />,
      title: "Fundamentals",
      description: "Learn the basics of programming, algorithms, and data structures.",
      href: "#python"
    },
    {
      icon: <Terminal className="h-12 w-12 text-indigo-600" />,
      title: "Interactive Practice",
      description: "Write and test code directly in your browser with instant feedback.",
      href: "#practice"
    },
    {
      icon: <FileCode2 className="h-12 w-12 text-indigo-600" />,
      title: "Projects",
      description: "Build real-world applications to reinforce your learning.",
      href: "#cpp"
    },
    {
      icon: <BrainCircuit className="h-12 w-12 text-indigo-600" />,
      title: "Problem Solving",
      description: "Enhance your logical thinking with coding challenges.",
      href: "#practice"
    }
  ];

  const handlePathClick = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Learning Paths</h2>
          <p className="mt-4 text-xl text-gray-600">Choose your path and start learning at your own pace</p>
        </div>
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          {paths.map((path, index) => (
            <div 
              key={index} 
              className="bg-white rounded-lg shadow-lg p-8 hover:shadow-xl transition duration-300 cursor-pointer"
              onClick={() => handlePathClick(path.href)}
            >
              <div className="flex justify-center mb-4">{path.icon}</div>
              <h3 className="text-xl font-semibold text-center mb-4">{path.title}</h3>
              <p className="text-gray-600 text-center">{path.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default LearningPaths;