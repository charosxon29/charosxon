import React, { useState } from 'react';
import { BrainCircuit, Code2, CheckCircle } from 'lucide-react';
import AlgorithmLesson from './practice/AlgorithmLesson';

const PracticeSection = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const practiceItems = [
    {
      title: "Basic Algorithms",
      description: "Practice fundamental algorithms like sorting, searching, and recursion",
      difficulty: "Beginner",
      tasks: ["Array manipulation", "String operations", "Basic math problems"]
    },
    {
      title: "Data Structures",
      description: "Implement and work with various data structures",
      difficulty: "Intermediate",
      tasks: ["Linked Lists", "Trees", "Hash Tables"]
    },
    {
      title: "Advanced Problems",
      description: "Tackle complex programming challenges",
      difficulty: "Advanced",
      tasks: ["Dynamic Programming", "Graph Algorithms", "System Design"]
    }
  ];

  if (selectedTopic === "Basic Algorithms") {
    return <AlgorithmLesson />;
  }

  return (
    <section id="practice" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">Practice Problems</h2>
          <p className="mt-4 text-xl text-gray-600">
            Enhance your skills with our curated collection of programming challenges
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {practiceItems.map((item, index) => (
            <div key={index} className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-semibold mb-4">{item.title}</h3>
              <p className="text-gray-600 mb-4">{item.description}</p>
              <div className="mb-4">
                <span className="inline-block bg-indigo-100 text-indigo-800 text-sm px-3 py-1 rounded-full">
                  {item.difficulty}
                </span>
              </div>
              <ul className="space-y-2">
                {item.tasks.map((task, taskIndex) => (
                  <li key={taskIndex} className="flex items-center text-gray-700">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    {task}
                  </li>
                ))}
              </ul>
              <button 
                className="mt-6 w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700"
                onClick={() => setSelectedTopic(item.title)}
              >
                Start Practice
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PracticeSection;