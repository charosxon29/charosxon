import React from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import InteractiveCpp from './InteractiveCpp';

const CppSection = () => {
  const cppExample = `// Basic C++ Example
#include <iostream>
using namespace std;

int factorial(int n) {
    if (n == 0 || n == 1)
        return 1;
    return n * factorial(n - 1);
}

int main() {
    int number = 5;
    cout << "Factorial of " << number << " is " 
         << factorial(number) << endl;
    return 0;
}`;

  const lessons = [
    {
      title: "C++ Fundamentals",
      topics: ["Basic Syntax", "Variables", "Data Types", "Control Structures"]
    },
    {
      title: "Object-Oriented Programming",
      topics: ["Classes", "Objects", "Inheritance", "Polymorphism"]
    },
    {
      title: "Memory Management",
      topics: ["Pointers", "References", "Dynamic Memory", "Smart Pointers"]
    }
  ];

  return (
    <section id="cpp" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900">C++ Track</h2>
          <p className="mt-4 text-xl text-gray-600">
            Master C++ and unlock powerful programming capabilities
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div className="bg-gray-900 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-white mb-4">Example Code</h3>
            <SyntaxHighlighter 
              language="cpp"
              style={atomDark}
              className="rounded-md"
            >
              {cppExample}
            </SyntaxHighlighter>
          </div>
          <div>
            <h3 className="text-2xl font-semibold mb-6">Why C++?</h3>
            <ul className="space-y-4 text-gray-600">
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">1</span>
                <span>High performance and efficient memory management</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">2</span>
                <span>Used in game development, system programming, and more</span>
              </li>
              <li className="flex items-start">
                <span className="h-6 w-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center mr-3">3</span>
                <span>Strong foundation for understanding computer science concepts</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-semibold mb-8 text-center">Course Curriculum</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {lessons.map((lesson, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg p-6">
                <h4 className="text-xl font-semibold mb-4">{lesson.title}</h4>
                <ul className="space-y-2">
                  {lesson.topics.map((topic, topicIndex) => (
                    <li key={topicIndex} className="flex items-center text-gray-600">
                      <span className="h-2 w-2 bg-indigo-600 rounded-full mr-2"></span>
                      {topic}
                    </li>
                  ))}
                </ul>
                <button className="mt-6 w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                  Start Lesson
                </button>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-semibold mb-8 text-center">Interactive Practice</h3>
          <InteractiveCpp />
        </div>
      </div>
    </section>
  );
};

export default CppSection;