import React from 'react';
import { Scissors, Ruler, Clock, Star, Phone, Mail, MapPin, Instagram, Facebook } from 'lucide-react';
import Hero from './components/Hero';
import Services from './components/Services';
import Portfolio from './components/Portfolio';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="bg-white shadow-sm fixed w-full z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center">
              <Scissors className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-semibold">Elite Tailors</span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#services" className="text-gray-700 hover:text-indigo-600">Services</a>
              <a href="#portfolio" className="text-gray-700 hover:text-indigo-600">Portfolio</a>
              <a href="#testimonials" className="text-gray-700 hover:text-indigo-600">Testimonials</a>
              <a href="#contact" className="text-gray-700 hover:text-indigo-600">Contact</a>
            </div>
            <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
              Book Appointment
            </button>
          </div>
        </div>
      </nav>

      <main>
        <Hero />
        <Services />
        <Portfolio />
        <Testimonials />
        <Contact />
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Elite Tailors</h3>
              <p className="text-gray-400">Crafting perfection, one stitch at a time.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Contact</h3>
              <div className="space-y-2">
                <p className="flex items-center"><Phone className="h-5 w-5 mr-2" /> +1 (555) 123-4567</p>
                <p className="flex items-center"><Mail className="h-5 w-5 mr-2" /> contact@elitetailors.com</p>
                <p className="flex items-center"><MapPin className="h-5 w-5 mr-2" /> 123 Fashion Street, NY</p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="hover:text-indigo-400"><Instagram className="h-6 w-6" /></a>
                <a href="#" className="hover:text-indigo-400"><Facebook className="h-6 w-6" /></a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center">
            <p className="text-gray-400">&copy; {new Date().getFullYear()} Elite Tailors. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;