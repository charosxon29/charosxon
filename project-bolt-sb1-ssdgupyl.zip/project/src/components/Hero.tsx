import React from 'react';

const Hero = () => {
  return (
    <div className="relative h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1558304970-abd247bd7b0e?auto=format&fit=crop&q=80"
          alt="Tailor working"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black opacity-50"></div>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Bespoke Tailoring<br />for the Modern Individual
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl">
            Experience the perfect fit with our expert tailoring services. Each garment is crafted to your exact measurements and style preferences.
          </p>
          <button className="bg-indigo-600 text-white px-8 py-3 rounded-md text-lg font-semibold hover:bg-indigo-700 transition duration-300">
            Book a Consultation
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;